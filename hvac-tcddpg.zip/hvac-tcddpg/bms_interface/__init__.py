"""BMS integration helpers."""
