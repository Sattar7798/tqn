"""Edge runtime that hosts the ONNX policy and talks to the BMS."""

from __future__ import annotations

import argparse
import asyncio
import json
from pathlib import Path

import numpy as np
import onnxruntime as ort

from .bacnet_client import BACnetClient, BACnetConfig


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="JSON config for the edge runtime.")
    return parser.parse_args()


async def main():
    args = parse_args()
    cfg = json.loads(Path(args.config).read_text())
    bacnet = BACnetClient(BACnetConfig(**cfg["bacnet"]))
    session = ort.InferenceSession(cfg["onnx_path"])
    while True:
        obs = np.zeros((1, cfg["obs_dim"]), dtype=np.float32)
        action = session.run(None, {"obs": obs})[0]
        await bacnet.write_property(("analogValue", 1), "presentValue", float(action[0, 0]))
        await asyncio.sleep(cfg.get("loop_seconds", 5))


if __name__ == "__main__":
    asyncio.run(main())
