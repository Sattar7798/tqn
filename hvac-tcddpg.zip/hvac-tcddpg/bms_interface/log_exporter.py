"""Placeholder for pushing telemetry to Grafana/Influx."""

from __future__ import annotations

def export(record):
    """Send record dict to telemetry backend (to be implemented)."""
    raise NotImplementedError("Implement Grafana/Influx export here.")
