"""BACnet/IP helper built on bacpypes3."""

from __future__ import annotations

from dataclasses import dataclass

from bacpypes3.app import BIPSimpleApplication
from bacpypes3.local.device import DeviceObject


@dataclass
class BACnetConfig:
    device_id: int
    address: str
    network: int


class BACnetClient:
    def __init__(self, config: BACnetConfig):
        self.device = DeviceObject(
            deviceIdentifier=config.device_id,
            maxApduLengthAccepted=1024,
            segmentationSupported="segmentedBoth",
            vendorIdentifier=15,
        )
        self.app = BIPSimpleApplication(self.device, config.address)

    async def write_property(self, object_identifier, property_name, value):
        await self.app.write_property(object_identifier, property_name, value)
