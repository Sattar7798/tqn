"""Run batches of EnergyPlus simulations to gather rollouts."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from hvac_tcddpg.envs import make_env


def parse_args():
    parser = argparse.ArgumentParser(description="Collect EnergyPlus rollouts for RC calibration.")
    parser.add_argument("--env-config", default="config/envs/eplus_5zone.yaml")
    parser.add_argument("--episodes", type=int, default=1)
    parser.add_argument("--output", default="data/rollouts/eplus_nominal.parquet")
    return parser.parse_args()


def main():
    args = parse_args()
    env = make_env(args.env_config)
    records = []
    for ep in range(args.episodes):
        obs, info = env.reset()
        done = False
        step_idx = 0
        while not done:
            action = env.action_space.sample()
            next_obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
            physical_action = env.normalizer.denormalize_action(action)
            record = {
                "episode": ep,
                "step": step_idx,
                "reward": reward,
                "terminated": terminated,
                "truncated": truncated,
            }
            raw_obs = info.get("raw_obs")
            if raw_obs is not None:
                for idx, val in enumerate(raw_obs):
                    record[f"obs_{idx}"] = val
            for idx, val in enumerate(physical_action):
                record[f"action_{idx}"] = val
            records.append(record)
            obs = next_obs
            step_idx += 1
    df = pd.DataFrame(records)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    df.to_parquet(args.output)
    print(f"Rollouts stored in {args.output}")


if __name__ == "__main__":
    main()
