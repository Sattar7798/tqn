"""Generate synthetic weather and occupancy assets for the standalone simulator."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


def parse_args():
    parser = argparse.ArgumentParser(description="Generate synthetic weather and occupancy data.")
    parser.add_argument("--hours", type=int, default=24 * 30, help="Number of hours to simulate.")
    parser.add_argument("--weather-path", default="data/weather/synth_weather.csv")
    parser.add_argument("--occupancy-path", default="data/schedules/synth_occupancy.csv")
    return parser.parse_args()


def main():
    args = parse_args()
    steps = args.hours * 12  # 5-minute steps
    time = np.arange(steps)
    outdoor_temp = 10 + 10 * np.sin(2 * np.pi * time / (24 * 12))
    rel_humidity = 0.4 + 0.1 * np.sin(2 * np.pi * time / (24 * 12) + np.pi / 4)
    solar_gain = np.clip(500 * np.sin(2 * np.pi * (time % (24 * 12)) / (12 * 12)), 0, None)
    weather = pd.DataFrame(
        {
            "timestep": time,
            "outdoor_temp": outdoor_temp,
            "rel_humidity": rel_humidity,
            "solar_gain": solar_gain,
        }
    )
    occ_base = np.where((time % (24 * 12)) / 12 >= 8, 1.0, 0.0) * np.where((time % (24 * 12)) / 12 <= 18, 1.0, 0.0)
    occupancy = pd.DataFrame(
        {
            "timestep": time,
            "core": 60 * occ_base,
            "east": 20 * occ_base,
            "west": 20 * occ_base,
            "south": 15 * occ_base,
            "north": 15 * occ_base,
        }
    )
    weather_path = Path(args.weather_path)
    occ_path = Path(args.occupancy_path)
    weather_path.parent.mkdir(parents=True, exist_ok=True)
    occ_path.parent.mkdir(parents=True, exist_ok=True)
    weather.to_csv(weather_path, index=False)
    occupancy.to_csv(occ_path, index=False)
    print(f"Wrote weather data to {weather_path}")
    print(f"Wrote occupancy schedule to {occ_path}")


if __name__ == "__main__":
    main()
