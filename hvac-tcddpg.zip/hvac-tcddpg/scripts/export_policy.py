"""Export TC-DDPG actor to ONNX."""

from __future__ import annotations

import argparse
from pathlib import Path

import torch

from hvac_tcddpg.agents.tc_ddpg.actor import Actor
from hvac_tcddpg.agents.tc_ddpg.config import NetworkConfig


def parse_args():
    parser = argparse.ArgumentParser(description="Export actor checkpoint to ONNX.")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--obs-dim", type=int, required=True)
    parser.add_argument("--act-dim", type=int, required=True)
    parser.add_argument("--output", default="models/tcddpg_edge.onnx")
    parser.add_argument("--hidden-dims", nargs="+", type=int, default=[512, 512, 256])
    return parser.parse_args()


def main():
    args = parse_args()
    actor = Actor(args.obs_dim, args.act_dim, tuple(args.hidden_dims))
    actor.load_state_dict(torch.load(args.checkpoint, map_location="cpu"))
    actor.eval()
    dummy_obs = torch.zeros(1, args.obs_dim, dtype=torch.float32)
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    torch.onnx.export(actor, dummy_obs, args.output, input_names=["obs"], output_names=["action"], opset_version=17)
    print(f"Exported ONNX policy to {args.output}")


if __name__ == "__main__":
    main()
