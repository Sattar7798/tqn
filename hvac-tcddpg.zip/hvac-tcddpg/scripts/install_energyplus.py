"""Utility to install and register EnergyPlus."""

from __future__ import annotations

import argparse
import shutil
import subprocess
import sys
from pathlib import Path


def parse_args():
    parser = argparse.ArgumentParser(description="Install EnergyPlus and record path in config.")
    parser.add_argument("--version", default="24.1", help="EnergyPlus version, e.g., 24.1")
    parser.add_argument("--dest", required=True, help="Destination directory for the install.")
    parser.add_argument("--installer", help="Optional path to a pre-downloaded installer.")
    return parser.parse_args()


def main():
    args = parse_args()
    dest = Path(args.dest)
    dest.parent.mkdir(parents=True, exist_ok=True)
    if args.installer:
        installer = Path(args.installer)
        subprocess.run([str(installer), "/S", f"/D={dest}"], check=True)
    else:
        print("Please download the EnergyPlus installer manually from energyplus.net and rerun with --installer.")
        sys.exit(1)

    env_cfg = Path("config/deployment/energyplus.yaml")
    env_cfg.parent.mkdir(parents=True, exist_ok=True)
    env_cfg.write_text(
        f"energyplus_root: {dest.as_posix()}\npreprocess_path: {dest.as_posix()}/PreProcess\npostprocess_path: {dest.as_posix()}/PostProcess\n"
    )
    print(f"EnergyPlus registered in {env_cfg}")


if __name__ == "__main__":
    main()
