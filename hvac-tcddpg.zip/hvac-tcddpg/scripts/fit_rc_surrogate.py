"""Fit RC surrogate parameters to EnergyPlus rollouts."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
from scipy.optimize import least_squares


def parse_args():
    parser = argparse.ArgumentParser(description="Fit RC model parameters.")
    parser.add_argument("--rollouts", nargs="+", required=True, help="Parquet files with state/action trajectories.")
    parser.add_argument("--output", required=True, help="Output npz file for RC parameters.")
    return parser.parse_args()


def main():
    args = parse_args()
    data = [pd.read_parquet(path) for path in args.rollouts]
    df = pd.concat(data, ignore_index=True)
    states = df.filter(like="state_").to_numpy()
    actions = df.filter(like="action_").to_numpy()
    next_states = np.roll(states, -1, axis=0)

    def residual(theta):
        a = theta[: states.shape[1] ** 2].reshape(states.shape[1], states.shape[1])
        b = theta[states.shape[1] ** 2 :].reshape(states.shape[1], actions.shape[1])
        pred = states + (a @ states.T).T + (b @ actions.T).T
        return (pred - next_states).ravel()

    theta0 = np.zeros(states.shape[1] ** 2 + states.shape[1] * actions.shape[1])
    res = least_squares(residual, theta0, max_nfev=200)
    n_state = states.shape[1]
    A = res.x[: n_state**2].reshape(n_state, n_state)
    B = res.x[n_state**2 :].reshape(n_state, actions.shape[1])
    out_path = Path(args.output)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    np.savez(out_path, A=A, B=B, bias=np.zeros(n_state))
    print(f"Saved RC parameters to {out_path}")


if __name__ == "__main__":
    main()
