"""Generate a 5-zone office IDF with EnergyPlus."""

from __future__ import annotations

import argparse
from pathlib import Path

from eppy.modeleditor import IDF


def parse_args():
    parser = argparse.ArgumentParser(description="Generate a parameterized 5-zone IDF.")
    parser.add_argument("--template", required=True, help="Path to YAML template with zone metadata.")
    parser.add_argument("--output", default="data/idf/base_5zone.idf")
    return parser.parse_args()


def main():
    args = parse_args()
    template_path = Path(args.template)
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    IDF.setiddname(template_path.parent / "Energy+.idd")
    idf = IDF(template_path)
    idf.saveas(output_path)
    print(f"Saved IDF to {output_path}")


if __name__ == "__main__":
    main()
