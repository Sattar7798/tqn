"""Plot scenario summaries and reward curves."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd


def parse_args():
    parser = argparse.ArgumentParser(description="Plot scenario evaluation results.")
    parser.add_argument("--scenario-csv", default="results/scenario_eval.csv")
    parser.add_argument("--output-dir", default="fig_out")
    return parser.parse_args()


def plot_bar(results: pd.DataFrame, output_dir: Path):
    plt.figure(figsize=(6, 4))
    bars = plt.bar(results["env"], results["mean_return"], color=["#1f77b4", "#ff7f0e"])
    plt.ylabel("Mean Return (higher is better)")
    plt.xticks(rotation=30, ha="right")
    plt.title("Scenario Comparison")
    for bar in bars:
        height = bar.get_height()
        plt.text(bar.get_x() + bar.get_width() / 2, height, f"{height:.1f}", ha="center", va="bottom")
    output_path = output_dir / "scenario_mean_return.png"
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()
    print(f"Wrote {output_path}")


def main():
    args = parse_args()
    df = pd.read_csv(args.scenario_csv)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    plot_bar(df, output_dir)


if __name__ == "__main__":
    main()
