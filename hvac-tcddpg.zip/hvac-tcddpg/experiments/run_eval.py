"""Evaluate a trained policy on the configured environment."""

from __future__ import annotations

import argparse
from pathlib import Path

import torch
import yaml

from hvac_tcddpg.envs import make_env
from hvac_tcddpg.agents import build_agent
from hvac_tcddpg.agents.tc_ddpg.config import AgentConfig, NetworkConfig


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env-config", default="config/envs/synth_5zone.yaml")
    parser.add_argument("--agent-config", default="config/agents/tc_ddpg.yaml")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--episodes", type=int, default=5)
    return parser.parse_args()


def load_agent_config(path: str) -> AgentConfig:
    cfg = yaml.safe_load(Path(path).read_text())
    network_cfg = cfg.get("network", {})
    return AgentConfig(
        actor_lr=cfg["actor_lr"],
        critic_lr=cfg["critic_lr"],
        gamma=cfg["gamma"],
        tau=cfg["tau"],
        batch_size=cfg["batch_size"],
        buffer_size=cfg["buffer_size"],
        update_freq=cfg["update_freq"],
        warmup_steps=cfg["warmup_steps"],
        device=cfg["device"],
        network=NetworkConfig(hidden_dims=tuple(network_cfg["hidden_dims"])),
    )


def main():
    args = parse_args()
    env = make_env(args.env_config)
    agent_cfg = load_agent_config(args.agent_config)
    agent = build_agent(agent_cfg, env.observation_space, env.action_space)
    device = next(agent.actor.parameters()).device
    agent.actor.load_state_dict(torch.load(args.checkpoint, map_location=device))
    returns = []
    for ep in range(args.episodes):
        obs, _ = env.reset()
        done = False
        episode_reward = 0.0
        while not done:
            action = agent.act(obs, noise=False)
            obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
            episode_reward += reward
        returns.append(episode_reward)
        print(f"Episode {ep}: reward={episode_reward:.2f}")
    print(f"Average return: {sum(returns)/len(returns):.2f}")


if __name__ == "__main__":
    main()
