"""Evaluate a checkpoint across multiple environment scenarios."""

from __future__ import annotations

import argparse
from pathlib import Path

import csv
import torch

from hvac_tcddpg.envs import make_env
from hvac_tcddpg.agents import build_agent
from hvac_tcddpg.agents.tc_ddpg.config import AgentConfig, NetworkConfig


def parse_args():
    parser = argparse.ArgumentParser(description="Scenario evaluation runner.")
    parser.add_argument("--env-configs", nargs="+", required=True)
    parser.add_argument("--agent-config", default="config/agents/tc_ddpg.yaml")
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--episodes", type=int, default=3)
    parser.add_argument("--output", default="results/scenario_eval.csv")
    return parser.parse_args()


def load_agent_config(path: str) -> AgentConfig:
    import yaml

    cfg = yaml.safe_load(Path(path).read_text())
    network_cfg = cfg.get("network", {})
    return AgentConfig(
        actor_lr=cfg["actor_lr"],
        critic_lr=cfg["critic_lr"],
        gamma=cfg["gamma"],
        tau=cfg["tau"],
        batch_size=cfg["batch_size"],
        buffer_size=cfg["buffer_size"],
        update_freq=cfg["update_freq"],
        warmup_steps=cfg["warmup_steps"],
        device=cfg["device"],
        network=NetworkConfig(hidden_dims=tuple(network_cfg["hidden_dims"])),
    )


def main():
    args = parse_args()
    agent_cfg = load_agent_config(args.agent_config)
    rows = []
    for env_cfg in args.env_configs:
        env = make_env(env_cfg)
        agent = build_agent(agent_cfg, env.observation_space, env.action_space)
        device = next(agent.actor.parameters()).device
        agent.actor.load_state_dict(torch.load(args.checkpoint, map_location=device))
        returns = []
        for _ in range(args.episodes):
            obs, _ = env.reset()
            done = False
            episode_return = 0.0
            while not done:
                action = agent.act(obs, noise=False)
                obs, reward, terminated, truncated, info = env.step(action)
                done = terminated or truncated
                episode_return += reward
            returns.append(episode_return)
        mean_return = sum(returns) / len(returns)
        rows.append({"env": env_cfg, "mean_return": mean_return})
        print(f"{env_cfg}: mean_return={mean_return:.2f}")

    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    with open(args.output, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=["env", "mean_return"])
        writer.writeheader()
        writer.writerows(rows)
    print(f"Wrote scenario summary to {args.output}")


if __name__ == "__main__":
    main()
