"""Plot training curves from TensorBoard event files."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from tensorboard.backend.event_processing.event_accumulator import EventAccumulator


def parse_args():
    parser = argparse.ArgumentParser(description="Plot training curves from TensorBoard logs.")
    parser.add_argument("--logdir", default="results/tb_longrun")
    parser.add_argument("--output-dir", default="fig_out")
    parser.add_argument("--smooth-window", type=int, default=10)
    return parser.parse_args()


def extract_scalars(logdir: str, tags):
    acc = EventAccumulator(logdir, size_guidance={"scalars": 0})
    acc.Reload()
    data = {}
    for tag in tags:
        events = acc.Scalars(tag)
        if not events:
            continue
        steps = [e.step for e in events]
        values = [e.value for e in events]
        data[tag] = pd.Series(values, index=steps)
    return data


def smooth(series: pd.Series, window: int):
    if window <= 1:
        return series
    return series.rolling(window=window, min_periods=1).mean()


def plot_series(series_dict, title, ylabel, output_path, smooth_window):
    plt.figure(figsize=(7, 4))
    for label, series in series_dict.items():
        smoothed = smooth(series, smooth_window)
        plt.plot(smoothed.index, smoothed.values, label=label)
    plt.xlabel("Step")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=200)
    plt.close()
    print(f"Wrote {output_path}")


def main():
    args = parse_args()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    scalars = extract_scalars(args.logdir, ["rollout/episode_reward", "loss/critic", "loss/actor", "eval/avg_return"])
    if "rollout/episode_reward" in scalars:
        plot_series(
            {"episode_reward": scalars["rollout/episode_reward"]},
            "Episode Reward",
            "Reward",
            output_dir / "training_episode_reward.png",
            args.smooth_window,
        )
    if "loss/critic" in scalars and "loss/actor" in scalars:
        plot_series(
            {"critic_loss": scalars["loss/critic"], "actor_loss": scalars["loss/actor"]},
            "Loss Curves",
            "Loss",
            output_dir / "training_losses.png",
            args.smooth_window,
        )
    if "eval/avg_return" in scalars:
        plot_series(
            {"eval_avg_return": scalars["eval/avg_return"]},
            "Evaluation Return",
            "Return",
            output_dir / "evaluation_return.png",
            args.smooth_window,
        )


if __name__ == "__main__":
    main()
