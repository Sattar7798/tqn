"""Entrypoint for training TC-DDPG agents with logging."""

from __future__ import annotations

import argparse
import time
from pathlib import Path

import torch
import yaml
from torch.utils.tensorboard import SummaryWriter

from hvac_tcddpg.envs import make_env
from hvac_tcddpg.agents import build_agent
from hvac_tcddpg.agents.tc_ddpg.config import AgentConfig, NetworkConfig


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--env-config", default="config/envs/synth_5zone.yaml")
    parser.add_argument("--agent-config", default="config/agents/tc_ddpg.yaml")
    parser.add_argument("--steps", type=int, default=200_000)
    parser.add_argument("--eval-interval", type=int, default=10_000)
    parser.add_argument("--eval-episodes", type=int, default=2)
    parser.add_argument("--logdir", default="results/tensorboard")
    parser.add_argument("--checkpoint-dir", default="models")
    parser.add_argument("--seed", type=int, default=0)
    return parser.parse_args()


def load_agent_config(path: str) -> AgentConfig:
    cfg = yaml.safe_load(Path(path).read_text())
    network_cfg = cfg.get("network", {})
    return AgentConfig(
        actor_lr=cfg["actor_lr"],
        critic_lr=cfg["critic_lr"],
        gamma=cfg["gamma"],
        tau=cfg["tau"],
        batch_size=cfg["batch_size"],
        buffer_size=cfg["buffer_size"],
        update_freq=cfg["update_freq"],
        warmup_steps=cfg["warmup_steps"],
        device=cfg["device"],
        network=NetworkConfig(hidden_dims=tuple(network_cfg["hidden_dims"])),
    )


def main():
    args = parse_args()
    Path(args.checkpoint_dir).mkdir(parents=True, exist_ok=True)
    writer = SummaryWriter(log_dir=args.logdir)
    env = make_env(args.env_config)
    agent_cfg = load_agent_config(args.agent_config)
    agent = build_agent(agent_cfg, env.observation_space, env.action_space)
    obs, _ = env.reset()
    episode_reward = 0.0
    episode_len = 0
    global_step = 0
    episode_idx = 0
    start_time = time.time()

    while global_step < args.steps:
        action = agent.act(obs)
        next_obs, reward, terminated, truncated, info = env.step(action)
        done = terminated or truncated
        agent.buffer.add(obs, action, reward, next_obs, float(done))
        obs = next_obs
        losses = agent.update()
        episode_reward += reward
        episode_len += 1
        global_step += 1

        if losses:
            writer.add_scalar("loss/critic", losses["critic_loss"], global_step)
            writer.add_scalar("loss/actor", losses["actor_loss"], global_step)

        if done:
            writer.add_scalar("rollout/episode_reward", episode_reward, global_step)
            writer.add_scalar("rollout/episode_length", episode_len, global_step)
            if "reward_components" in info:
                for name, value in info["reward_components"].items():
                    writer.add_scalar(f"reward_components/{name}", value, global_step)
            obs, _ = env.reset()
            episode_reward = 0.0
            episode_len = 0
            episode_idx += 1

        if args.eval_interval and global_step % args.eval_interval == 0:
            avg_return = evaluate(agent, env, episodes=args.eval_episodes)
            writer.add_scalar("eval/avg_return", avg_return, global_step)
            ckpt_path = Path(args.checkpoint_dir) / f"tcddpg_step{global_step}.pt"
            torch.save(agent.actor.state_dict(), ckpt_path)

    elapsed = time.time() - start_time
    final_ckpt = Path(args.checkpoint_dir) / "tcddpg_final.pt"
    torch.save(agent.actor.state_dict(), final_ckpt)
    print(f"Training loop finished in {elapsed/60:.2f} minutes. Final checkpoint at {final_ckpt}.")


def evaluate(agent, env, episodes: int = 1) -> float:
    returns = []
    for _ in range(episodes):
        obs, _ = env.reset()
        done = False
        episode_return = 0.0
        while not done:
            action = agent.act(obs, noise=False)
            obs, reward, terminated, truncated, info = env.step(action)
            done = terminated or truncated
            episode_return += reward
        returns.append(episode_return)
    return sum(returns) / len(returns)


if __name__ == "__main__":
    main()
