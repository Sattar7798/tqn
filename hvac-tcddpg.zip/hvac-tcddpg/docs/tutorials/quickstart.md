# Quickstart

## Stand-alone Surrogate Path

1. `poetry install`
2. `poetry run python scripts/generate_synthetic_assets.py --hours 168`
3. `poetry run python experiments/run_training.py --env-config config/envs/synth_5zone.yaml --agent-config config/agents/tc_ddpg.yaml --steps 100000`
4. `poetry run python experiments/run_eval.py --env-config config/envs/synth_5zone.yaml --checkpoint models/tcddpg_step100000.pt`
5. `poetry run python experiments/run_scenarios.py --env-configs config/envs/synth_5zone.yaml config/envs/synth_faults.yaml --checkpoint models/tcddpg_step100000.pt --output results/scenario_eval.csv`
6. `poetry run python scripts/export_policy.py --checkpoint models/tcddpg_step100000.pt --obs-dim 7 --act-dim 4 --output models/tcddpg_edge.onnx`

## Optional EnergyPlus Path

1. `poetry run python scripts/install_energyplus.py --version 24.1 --dest C:\EnergyPlusV24-1-0 --installer <path>`
2. `poetry run python scripts/make_5zone_idf.py --template docs/assets/5zone_template.idf`
3. `poetry run python scripts/run_eplus_batch.py --env-config config/envs/eplus_5zone.yaml --episodes 2`
4. `poetry run python scripts/fit_rc_surrogate.py --rollouts data/rollouts/eplus_nominal.parquet --output data/rc_params/5zone_params.npz`
5. Continue with the training/eval commands above but switch `--env-config` to the EnergyPlus YAML once the simulator is installed.
