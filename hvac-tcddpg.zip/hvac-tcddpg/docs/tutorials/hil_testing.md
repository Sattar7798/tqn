# Hardware-in-the-Loop Testing

1. Flash Raspberry Pi OS on CM4, install Python 3.11 and `onnxruntime`.
2. Export the policy with `poetry run python scripts/export_policy.py --checkpoint models/tcddpg_stepXXXXX.pt --obs-dim 7 --act-dim 4 --output models/tcddpg_edge.onnx`.
3. Copy `bms_interface/edge_runtime.py`, `config/deployment/hil_pi.yaml`, and the ONNX file to the Pi.
4. Launch EnergyPlus on the host with BCVTB socket bridged to the Pi IP/port.
5. Start the edge runtime: `python edge_runtime.py --config config/deployment/hil_pi.yaml`.
6. Monitor Grafana dashboards fed by `bms_interface/log_exporter.py`.
7. Trigger emergency fallback by grounding the safety GPIO or sending MQTT message `hil/fallback`.
