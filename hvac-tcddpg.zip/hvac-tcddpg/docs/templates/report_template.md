# Experiment Report Template

- **Building model:**  
- **Agent version:**  
- **Simulation dates:**  
- **Fault scenario:**  
- **Baselines compared:**  

## 1. Objective
Describe what you tested.

## 2. Methodology
- Environment config  
- Agent config  
- Seeds  
- Disturbances/faults  

## 3. Results
Insert figures (comfort vs energy, violation histograms, convergence).

## 4. Statistical tests
Summaries of CIs, bootstrap results, effect sizes.

## 5. Failure analysis
Notable violations, fallback triggers, BMS overrides.
