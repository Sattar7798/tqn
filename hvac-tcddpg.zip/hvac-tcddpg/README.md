# HVAC TC-DDPG Controller

This repository hosts a production-oriented implementation of the thermodynamics-constrained DDPG (TC-DDPG) framework for HVAC supervision. The goal is to bridge high-fidelity building simulation (EnergyPlus) with reduced-order RC surrogates, physics-based reward shaping, and deployment pathways for building management systems (BMS).

## Repository Layout

```
hvac-tcddpg/
├── config/           # YAML configs for envs, agents, experiments, deployment
├── data/             # IDFs, weather files, schedule CSVs, calibration data
├── docs/             # Tutorials, API docs, experiment templates
├── experiments/      # Training, evaluation, hyper-parameter sweeps
├── scripts/          # Utilities (EnergyPlus install, RC fitting, policy export)
├── src/hvac_tcddpg/  # Python package (envs, agents, physics layers, BMS interface)
└── tests/            # Unit and integration tests
```

## Quickstart

```bash
pip install poetry
cd hvac-tcddpg
poetry install
# Generate standalone weather + occupancy assets (no EnergyPlus required)
poetry run python scripts/generate_synthetic_assets.py --hours 168
# Launch training on the synthetic high-fidelity surrogate
poetry run python experiments/run_training.py --env-config config/envs/synth_5zone.yaml --agent-config config/agents/tc_ddpg.yaml --steps 100000
# Evaluate the exported actor
poetry run python experiments/run_eval.py --env-config config/envs/synth_5zone.yaml --checkpoint models/tcddpg_step100000.pt
# Compare multiple scenarios (nominal + faulted) and plot
poetry run python experiments/run_scenarios.py --env-configs config/envs/synth_5zone.yaml config/envs/synth_faults.yaml --checkpoint models/tcddpg_step100000.pt --output results/scenario_eval.csv
poetry run python experiments/plot_results.py --scenario-csv results/scenario_eval.csv --output-dir fig_out
# Plot training curves from TensorBoard logs
poetry run python experiments/plot_training_curves.py --logdir results/tb_longrun --output-dir fig_out
```

To work with the optional EnergyPlus backend later, see the advanced instructions under `docs/tutorials/quickstart.md`.

See `docs/tutorials/quickstart.md` for a step-by-step walkthrough, `docs/tutorials/hil_testing.md` for hardware-in-the-loop procedures, and the `docs/templates/report_template.md` file when writing experiment reports.

## Training & Evaluation

- Launch stand-alone surrogate training: `poetry run python experiments/run_training.py --env-config config/envs/synth_5zone.yaml --agent-config config/agents/tc_ddpg.yaml`.
- Run RC-only experiments: switch to `config/envs/rc_5zone.yaml`.
- Faulted/disturbed scenarios are described in `config/envs/synth_faults.yaml`; evaluate via `experiments/run_scenarios.py` and visualize via `experiments/plot_results.py`.
- Plot training/eval curves from TensorBoard logs with `experiments/plot_training_curves.py`.
- EnergyPlus fine-tuning remains available if you install the simulator and update `config/envs/eplus_5zone.yaml`.
- Evaluate checkpoints: `poetry run python experiments/run_eval.py --checkpoint models/tcddpg_stepXXXX.pt`.

TensorBoard logs are stored under `results/tensorboard`. Checkpoint files land in `models/`.

## Deployment

1. Export the actor to ONNX: `poetry run python scripts/export_policy.py --checkpoint models/tcddpg_stepXXXX.pt --obs-dim 7 --act-dim 4`.
2. Configure BACnet/IP endpoints in `config/deployment/hil_pi.yaml`.
3. Run the edge supervisor on Raspberry Pi or similar device: `python bms_interface/edge_runtime.py --config config/deployment/hil_pi.yaml`.

See the HIL tutorial for safety envelopes, fallbacks, and monitoring guidance and update the observation/action dims if you change the environment configuration.
