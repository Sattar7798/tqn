"""Thermodynamic feasibility projection for HVAC actions."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np

from .psychro import humidity_ratio_from_rh, clamp_rel_humidity


@dataclass
class ProjectionSettings:
    sat_bounds: Tuple[float, float]
    sat_rate_limit: float
    flow_min: float
    flow_max: float
    humidity_bounds: Tuple[float, float]
    prev_action_weight: float = 0.0


class ThermoProjection:
    """Project actions into a physically admissible subset."""

    def __init__(self, **kwargs):
        self.settings = ProjectionSettings(**kwargs)
        self._prev_action = None

    def __call__(self, action: np.ndarray, state: np.ndarray) -> Tuple[np.ndarray, Dict]:
        act = action.copy()
        penalties = {}
        act[0], penalties["sat_penalty"] = self._clip_sat(act[0])
        act[1], penalties["flow_penalty"] = self._clip_flow(act[1])
        act[2], penalties["humidity_penalty"] = self._clip_humidity(act[2], state)
        total_penalty = sum(penalties.values())
        penalties["penalty"] = total_penalty
        self._prev_action = act
        return act, penalties

    def _clip_sat(self, sat: float) -> Tuple[float, float]:
        lo, hi = self.settings.sat_bounds
        clipped = np.clip(sat, lo, hi)
        penalty = abs(clipped - sat)
        if self._prev_action is not None:
            delta = clipped - self._prev_action[0]
            rate_limited = np.clip(delta, -self.settings.sat_rate_limit, self.settings.sat_rate_limit)
            clipped = self._prev_action[0] + rate_limited
            penalty += abs(delta - rate_limited)
        return clipped, penalty

    def _clip_flow(self, flow: float) -> Tuple[float, float]:
        clipped = np.clip(flow, self.settings.flow_min, self.settings.flow_max)
        penalty = abs(clipped - flow)
        if self._prev_action is not None:
            delta = clipped - self._prev_action[1]
            clipping = np.clip(delta, -0.1, 0.1)
            clipped = self._prev_action[1] + clipping
            penalty += abs(delta - clipping)
        return clipped, penalty

    def _clip_humidity(self, humidifier: float, state: np.ndarray) -> Tuple[float, float]:
        rh = clamp_rel_humidity(state[-1])
        w = humidity_ratio_from_rh(state[-2], rh)
        lo, hi = self.settings.humidity_bounds
        clipped = np.clip(humidifier + w, lo, hi) - w
        penalty = abs(clipped - humidifier)
        return clipped, penalty
