"""Energy balance utilities for RC models."""

from __future__ import annotations

from typing import Dict

import numpy as np


def rc_step(state: np.ndarray, action: np.ndarray, params: Dict[str, np.ndarray], delta_t_hours: float) -> np.ndarray:
    """Integrate multi-zone RC dynamics forward by one step.

    Args:
        state: Current state vector (zone temps, wall temps, humidity buckets...).
        action: Control actions (normalized).
        params: Dictionary with conductance matrices, capacitances, gains.
        delta_t_hours: Integration step size in hours.
    """
    A = params["A"]
    B = params["B"]
    bias = params.get("bias", np.zeros_like(state))
    next_state = state + delta_t_hours * (A @ state + B @ action + bias)
    return next_state
