"""Psychrometric helper functions."""

from __future__ import annotations

import numpy as np

P_ATM = 101325.0


def saturation_pressure(temp_c: float) -> float:
    temp_k = temp_c + 273.15
    return np.exp(77.345 + 0.0057 * temp_k - 7235.0 / temp_k) / temp_k ** 8.2


def humidity_ratio_from_rh(temp_c: float, rh: float, p_atm: float = P_ATM) -> float:
    p_ws = saturation_pressure(temp_c)
    return 0.62198 * rh * p_ws / (p_atm - rh * p_ws)


def clamp_rel_humidity(rh: float) -> float:
    return float(np.clip(rh, 0.05, 0.95))
