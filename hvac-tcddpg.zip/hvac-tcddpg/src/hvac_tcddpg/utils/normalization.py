"""Observation and action normalization helpers."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict

import numpy as np


@dataclass
class NormalizationStats:
    obs_mean: np.ndarray
    obs_std: np.ndarray
    action_mean: np.ndarray
    action_std: np.ndarray

    @classmethod
    def from_dict(cls, stats: Dict):
        return cls(
            obs_mean=np.asarray(stats.get("mean"), dtype=np.float32),
            obs_std=np.asarray(stats.get("std"), dtype=np.float32),
            action_mean=np.asarray(stats.get("action_mean"), dtype=np.float32),
            action_std=np.asarray(stats.get("action_std"), dtype=np.float32),
        )


class Normalizer:
    """Applies fixed affine transforms to observations/actions."""

    def __init__(self, stats_path: str | None):
        self.stats = None
        if stats_path:
            stats_dict = _load_stats(stats_path)
            self.stats = NormalizationStats.from_dict(stats_dict)

    def normalize_obs(self, obs: np.ndarray) -> np.ndarray:
        if not self.stats:
            return obs
        return (obs - self.stats.obs_mean) / (self.stats.obs_std + 1e-6)

    def denormalize_action(self, action: np.ndarray) -> np.ndarray:
        if not self.stats:
            return action
        return action * (self.stats.action_std + 1e-6) + self.stats.action_mean

    def normalize_action(self, action: np.ndarray) -> np.ndarray:
        if not self.stats:
            return action
        return (action - self.stats.action_mean) / (self.stats.action_std + 1e-6)


def _load_stats(path: str) -> Dict:
    path_obj = Path(path)
    if path_obj.suffix == ".json":
        import json

        return json.loads(path_obj.read_text())
    raise ValueError(f"Unsupported stats format for {path}")
