"""HVAC TC-DDPG package."""

from importlib.metadata import version, PackageNotFoundError


try:
    __version__ = version("hvac-tcddpg")
except PackageNotFoundError:  # pragma: no cover - during local dev
    __version__ = "0.0.0"
