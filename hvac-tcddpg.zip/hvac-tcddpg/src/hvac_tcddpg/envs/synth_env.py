"""Self-contained synthetic building environment."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict

import gymnasium as gym
import numpy as np
import pandas as pd

from .base_env import EnvConfig, HVACEnv
from .reward import RewardModel
from .disturbance_manager import build_disturbances, apply_disturbances
from ..physics.energy_balance import rc_step
from ..physics.thermo_projection import ThermoProjection


@dataclass
class SynthBackendSettings:
    params_path: str
    weather_path: str
    occupancy_path: str
    projection: Dict
    weather_gain: float = 0.02
    occupancy_gain: float = 0.001
    process_noise: float = 0.05
    episode_steps: int | None = None


class SyntheticHVACEnv(HVACEnv):
    """High-fidelity surrogate built entirely in Python."""

    def __init__(self, config: EnvConfig, backend_settings: Dict):
        super().__init__(config)
        self.settings = SynthBackendSettings(**backend_settings)
        base = Path(config.config_dir or ".")
        self.params = self._load_params(base / self.settings.params_path)
        self.weather = pd.read_csv(base / self.settings.weather_path)
        self.occupancy = pd.read_csv(base / self.settings.occupancy_path)
        self._dataset_len = min(len(self.weather), len(self.occupancy))
        self._episode_len = self.settings.episode_steps or self._dataset_len
        self.observation_space = gym.spaces.Box(
            low=-np.inf, high=np.inf, shape=(len(config.observation_items),), dtype=np.float32
        )
        self.action_space = gym.spaces.Box(
            low=-1.0, high=1.0, shape=(len(config.action_items),), dtype=np.float32
        )
        self._projection = ThermoProjection(**self.settings.projection)
        self._reward_model = RewardModel(config.reward, config.observation_items) if config.reward else None
        self._time_index = 0
        self._dataset_index = 0
        self._episode_step = 0
        self._state = np.zeros(len(self.params["A"]), dtype=np.float64)
        self._prev_action = np.zeros(len(config.action_items), dtype=np.float64)
        self._zone_names = [name for name in config.observation_items if name.startswith("state_zone")]
        self._zone_lookup = {name: idx for idx, name in enumerate(self._zone_names)}
        self._disturbances = build_disturbances(config.disturbances)

    @staticmethod
    def _load_params(path: str) -> Dict[str, np.ndarray]:
        params = np.load(Path(path), allow_pickle=True)
        return {k: params[k] for k in params.files}

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed, options=options)
        self._time_index = 0
        self._dataset_index = 0
        self._episode_step = 0
        self._state = np.zeros_like(self._state)
        obs = self._extract_observation()
        norm_obs = self._normalize_obs(obs)
        info = {"time_index": self._time_index, "raw_obs": obs}
        return norm_obs, info

    def step(self, action: np.ndarray):
        physical_action = self._denormalize_action(action)
        obs_raw = self._extract_observation()
        obs_dist, physical_action = apply_disturbances(obs_raw, physical_action, self._disturbances)
        self._state[: len(obs_dist)] = obs_dist[: len(self._state)]
        projected, proj_info = self._projection(physical_action, self._state)
        thermal_disturbance = self._weather_term() + self._occupancy_term()
        noise = np.random.randn(*self._state.shape) * self.settings.process_noise
        next_state = rc_step(self._state, projected, self.params, self.delta_t_hours) + thermal_disturbance + noise
        self._state = next_state
        self._prev_action = projected
        obs = self._extract_observation()
        norm_obs = self._normalize_obs(obs)
        reward_info = {"projection": proj_info, "raw_obs": obs, "energy_proxy": float(np.linalg.norm(projected))}
        reward = self._compute_reward(obs, projected, reward_info)
        self._dataset_index = (self._dataset_index + 1) % self._dataset_len
        self._episode_step += 1
        terminated = self._episode_step >= self._episode_len
        if terminated:
            self._episode_step = 0
        return norm_obs, reward, terminated, False, reward_info

    def _extract_observation(self):
        obs = []
        for name in self.config.observation_items:
            if name.startswith("state_zone"):
                zone_idx = self._zone_lookup.get(name, 0)
                obs.append(self._state[zone_idx])
            elif name == "outdoor_temp":
                obs.append(self._current_weather()["outdoor_temp"])
            elif name == "supply_air_temp":
                obs.append(self._prev_action[0])
            else:
                obs.append(0.0)
        return np.asarray(obs, dtype=np.float32)

    def _current_weather(self):
        return self.weather.iloc[self._dataset_index]

    def _current_occupancy(self):
        return self.occupancy.iloc[self._dataset_index]

    def _weather_term(self):
        out_temp = self._current_weather()["outdoor_temp"]
        delta = (out_temp - self._state[0]) * self.settings.weather_gain
        return np.ones_like(self._state) * delta

    def _occupancy_term(self):
        occ = self._current_occupancy()
        loads = np.array([occ.get(col, 0.0) for col in ["core", "east", "west", "south", "north"]])
        loads = np.pad(loads, (0, max(0, len(self._state) - len(loads))))
        return loads * self.settings.occupancy_gain

    def _compute_reward(self, obs: np.ndarray, action: np.ndarray, info: Dict):
        info["humidity"] = 0.4
        if self._reward_model:
            reward, components = self._reward_model(obs, action, info)
            info["reward_components"] = components
            return reward
        return -np.linalg.norm(action)
