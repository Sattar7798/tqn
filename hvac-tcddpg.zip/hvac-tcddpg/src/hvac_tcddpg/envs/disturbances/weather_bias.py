"""Bias outdoor temperature observations."""

from __future__ import annotations

import numpy as np

from .base import Disturbance


class WeatherBias(Disturbance):
    """Adds a constant and noisy bias to selected observation indices."""

    def __init__(self, indices, bias: float = 1.0, noise_std: float = 0.2):
        super().__init__(indices=indices, bias=bias, noise_std=noise_std)
        self.indices = indices
        self.bias = bias
        self.noise_std = noise_std

    def apply_obs(self, obs: np.ndarray) -> np.ndarray:
        corrupted = obs.copy()
        noise = np.random.randn(len(self.indices)) * self.noise_std
        for idx, n in zip(self.indices, noise):
            corrupted[idx] += self.bias + n
        return corrupted

    def apply_action(self, action: np.ndarray) -> np.ndarray:
        return action
