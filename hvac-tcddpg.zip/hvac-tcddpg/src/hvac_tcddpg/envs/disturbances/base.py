"""Disturbance base classes."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Dict

import numpy as np


class Disturbance(ABC):
    """Interface for modifying observations or actions."""

    def __init__(self, **kwargs):
        self.params = kwargs

    @abstractmethod
    def apply_obs(self, obs: np.ndarray) -> np.ndarray:
        return obs

    @abstractmethod
    def apply_action(self, action: np.ndarray) -> np.ndarray:
        return action

    def info(self) -> Dict:
        return {}
