"""Sensor noise models."""

from __future__ import annotations

import numpy as np

from .base import Disturbance


class SensorNoise(Disturbance):
    """Additive Gaussian noise with optional bias and drift."""

    def __init__(self, std: float, bias: float = 0.0, drift_rate: float = 0.0, dropout_prob: float = 0.0):
        super().__init__(std=std, bias=bias, drift_rate=drift_rate, dropout_prob=dropout_prob)
        self.std = std
        self.bias = bias
        self.drift_rate = drift_rate
        self.dropout_prob = dropout_prob
        self._drift_state = 0.0

    def apply_obs(self, obs: np.ndarray) -> np.ndarray:
        self._drift_state += np.random.randn() * self.drift_rate
        noise = np.random.randn(*obs.shape) * self.std + self.bias + self._drift_state
        mask = np.random.rand(*obs.shape) < self.dropout_prob
        corrupted = obs.copy()
        corrupted += noise
        corrupted[mask] = obs[mask]
        return corrupted

    def apply_action(self, action: np.ndarray) -> np.ndarray:
        return action
