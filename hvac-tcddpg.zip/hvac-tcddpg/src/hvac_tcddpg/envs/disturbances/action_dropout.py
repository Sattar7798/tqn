"""Random action dropout / override disturbance."""

from __future__ import annotations

import numpy as np

from .base import Disturbance


class ActionDropout(Disturbance):
    """Occasionally replace actions with previous ones to emulate BMS overrides."""

    def __init__(self, dropout_prob: float = 0.05):
        super().__init__(dropout_prob=dropout_prob)
        self.dropout_prob = dropout_prob
        self._last_action = None

    def apply_obs(self, obs: np.ndarray) -> np.ndarray:
        return obs

    def apply_action(self, action: np.ndarray) -> np.ndarray:
        if self._last_action is None:
            self._last_action = action.copy()
            return action
        mask = np.random.rand(*action.shape) < self.dropout_prob
        out = action.copy()
        out[mask] = self._last_action[mask]
        self._last_action = out.copy()
        return out
