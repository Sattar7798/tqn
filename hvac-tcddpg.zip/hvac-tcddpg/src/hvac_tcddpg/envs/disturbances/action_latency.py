"""Action latency disturbance."""

from __future__ import annotations

import numpy as np

from .base import Disturbance


class ActionLatency(Disturbance):
    """Replay past actions to mimic actuator latency."""

    def __init__(self, delay_steps: int = 1):
        super().__init__(delay_steps=delay_steps)
        self.delay_steps = max(1, delay_steps)
        self._queue = None

    def apply_obs(self, obs: np.ndarray) -> np.ndarray:
        return obs

    def apply_action(self, action: np.ndarray) -> np.ndarray:
        if self._queue is None:
            self._queue = [action.copy() for _ in range(self.delay_steps)]
            return action
        delayed = self._queue.pop(0)
        self._queue.append(action.copy())
        return delayed
