"""Actuator fault models."""

from __future__ import annotations

import numpy as np

from .base import Disturbance


class StuckActuator(Disturbance):
    """Force an actuator channel to remain at a fixed value."""

    def __init__(self, index: int, value: float, probability: float = 1.0):
        super().__init__(index=index, value=value, probability=probability)
        self.index = index
        self.value = value
        self.probability = probability
        self._active = False

    def apply_obs(self, obs: np.ndarray) -> np.ndarray:
        return obs

    def apply_action(self, action: np.ndarray) -> np.ndarray:
        if not self._active and np.random.rand() < self.probability:
            self._active = True
        if self._active:
            action = action.copy()
            action[self.index] = self.value
        return action
