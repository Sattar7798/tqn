"""Mappings between RL signals and EnergyPlus handles."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict


@dataclass(frozen=True)
class ActuatorSpec:
    component_type: str
    control_type: str
    component_name: str


@dataclass(frozen=True)
class SensorSpec:
    variable_name: str
    key: str


class MappingRegistry:
    def __init__(self):
        self.actuators: Dict[str, ActuatorSpec] = {}
        self.sensors: Dict[str, SensorSpec] = {}

    def register_actuator(self, name: str, spec: ActuatorSpec):
        self.actuators[name] = spec

    def register_sensor(self, name: str, spec: SensorSpec):
        self.sensors[name] = spec

    def to_config(self) -> Dict:
        return {
            "actuators": {name: spec.__dict__ for name, spec in self.actuators.items()},
            "sensors": {name: spec.__dict__ for name, spec in self.sensors.items()},
        }
