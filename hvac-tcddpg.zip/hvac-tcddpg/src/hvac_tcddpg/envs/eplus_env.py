"""EnergyPlus-backed HVAC environment."""

from __future__ import annotations

import queue
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List

import gymnasium as gym
import numpy as np

try:
    from energyplus_api import EnergyPlusAPI  # type: ignore
except ModuleNotFoundError as exc:  # pragma: no cover
    raise ImportError(
        "EnergyPlus API not available. Install the `energyplus` Python package before using EnergyPlusHVACEnv."
    ) from exc

from .base_env import EnvConfig, HVACEnv
from .reward import RewardModel
from ..physics.thermo_projection import ThermoProjection


@dataclass
class EnergyPlusBackendSettings:
    idf_path: str
    epw_path: str
    api_port: int | None = None
    warmup_days: int = 5
    projection: Dict | None = None


class EnergyPlusHVACEnv(HVACEnv):
    """Gym wrapper that controls EnergyPlus via the official Python API."""

    def __init__(self, config: EnvConfig, backend_settings: Dict):
        super().__init__(config)
        self.settings = EnergyPlusBackendSettings(**backend_settings)
        self.api = EnergyPlusAPI()
        self.runtime = self.api.runtime
        self.exchange = self.api.exchange
        self._observation_queue: "queue.Queue[np.ndarray]" = queue.Queue()
        self._reward_queue: "queue.Queue[float]" = queue.Queue()
        self._terminated = False
        self._projection = (
            ThermoProjection(**self.settings.projection) if self.settings.projection else None
        )
        self._reward_model = RewardModel(config.reward, config.observation_items) if config.reward else None
        self.action_space = gym.spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(len(config.action_items),),
            dtype=np.float32,
        )
        self.observation_space = gym.spaces.Box(
            low=-np.inf,
            high=np.inf,
            shape=(len(config.observation_items),),
            dtype=np.float32,
        )
        self._actuator_handles: Dict[str, int] = {}
        self._sensor_handles: Dict[str, int] = {}
        self._last_action = np.zeros(len(config.action_items), dtype=np.float32)
        self._info_cache: Dict = {}
        self._latest_obs_raw = np.zeros(len(config.observation_items), dtype=np.float32)

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed, options=options)
        self._terminated = False
        self._actuator_handles.clear()
        self._sensor_handles.clear()
        self._start_simulation()
        obs = self._observation_queue.get(timeout=60)
        info = {"time_index": 0}
        return obs, info

    def step(self, action: np.ndarray):
        proj_info = {}
        physical_action = self._denormalize_action(action)
        if self._projection:
            physical_action, proj_info = self._projection(physical_action, np.zeros(1))
        self._apply_action(physical_action)
        self._last_action = physical_action
        obs = self._observation_queue.get(timeout=60)
        reward = self._reward_queue.get(timeout=60)
        terminated = self._terminated
        info = {"projection": proj_info, **self._info_cache}
        return obs, reward, terminated, False, info

    # Internal helpers -----------------------------------------------------
    def _start_simulation(self):
        def _report_callback(state_argument):
            obs = self._collect_observations()
            reward = self._compute_reward(obs)
            self._reward_queue.put(reward)

        def _terminate_callback(state_argument):
            self._terminated = True

        self.runtime.callback_after_new_environment_warmup_complete(_report_callback)
        self.runtime.callback_end_zone_timestep_after_zone_reporting(_report_callback)
        self.runtime.callback_end_of_system_timestep_after_hvac_reporting(_report_callback)
        self.runtime.callback_end_of_zone_timestep_after_zone_reporting(_terminate_callback)
        self.runtime.run_energyplus(
            [
                "-w",
                self.settings.epw_path,
                "-d",
                str(Path("fig_out")),
                "-r",
                self.settings.idf_path,
            ]
        )

    def _collect_observations(self):
        obs = []
        for item in self.config.observation_items:
            if item not in self._sensor_handles:
                self._sensor_handles[item] = self.exchange.get_variable_handle(
                    self.api.state, item, "HVACTC-DDPG"
                )
            obs_value = self.exchange.get_variable_value(self.api.state, self._sensor_handles[item])
            obs.append(obs_value)
        obs_vec = np.asarray(obs, dtype=np.float32)
        self._latest_obs_raw = obs_vec
        norm_obs = self._normalize_obs(obs_vec)
        self._observation_queue.put(norm_obs)
        self._info_cache = {"energy_proxy": float(np.linalg.norm(self._last_action)), "raw_obs": obs_vec}
        return obs_vec

    def _apply_action(self, action: np.ndarray):
        for idx, name in enumerate(self.config.action_items):
            if name not in self._actuator_handles:
                self._actuator_handles[name] = self.exchange.get_actuator_handle(
                    self.api.state, "HVACTC-DDPG", name
                )
            self.exchange.set_actuator_value(
                self.api.state, self._actuator_handles[name], float(action[idx])
            )

    def _compute_reward(self, obs: np.ndarray) -> float:
        if not self._reward_model:
            return -float(np.linalg.norm(self._last_action))
        reward, components = self._reward_model(self._latest_obs_raw, self._last_action, self._info_cache)
        self._info_cache["reward_components"] = components
        return reward
