"""Physics-informed reward calculation."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Iterable, Tuple

import numpy as np


@dataclass
class RewardWeights:
    energy: float = 1.0
    comfort: float = 2.0
    violation: float = 5.0
    humidity: float = 1.0
    wear: float = 0.1
    residual: float = 0.5


@dataclass
class RewardConfig:
    weights: RewardWeights
    comfort_targets: Dict[str, float]
    comfort_band: float
    humidity_bounds: Tuple[float, float]
    energy_costs: Dict[str, float] | None = None


def _build_reward_config(cfg: Dict) -> RewardConfig:
    weights_cfg = cfg.get("weights", {})
    weights = RewardWeights(
        energy=weights_cfg.get("energy", 1.0),
        comfort=weights_cfg.get("comfort", 2.0),
        violation=weights_cfg.get("violation", 5.0),
        humidity=weights_cfg.get("humidity", 1.0),
        wear=weights_cfg.get("wear", 0.1),
        residual=weights_cfg.get("residual", 0.5),
    )
    return RewardConfig(
        weights=weights,
        comfort_targets=cfg.get("comfort_targets", {}),
        comfort_band=cfg.get("comfort_band", 0.5),
        humidity_bounds=tuple(cfg.get("humidity_bounds", (0.3, 0.6))),
        energy_costs=cfg.get("energy_costs"),
    )


class RewardModel:
    """Aggregates reward components from observations and info dicts."""

    def __init__(self, config: Dict, observation_labels: Iterable[str]):
        self.config = _build_reward_config(config)
        self._obs_index = {name: idx for idx, name in enumerate(observation_labels)}
        self._prev_action: np.ndarray | None = None

    def __call__(self, observation_vector: np.ndarray, action_vector: np.ndarray, info: Dict) -> Tuple[float, Dict]:
        w = self.config.weights
        comfort = self._comfort_penalty(observation_vector)
        humidity = self._humidity_penalty(observation_vector, info)
        violation = info.get("projection", {}).get("penalty", 0.0)
        residual = info.get("energy_balance_residual", 0.0)
        energy = info.get("energy_proxy", float(np.linalg.norm(action_vector, ord=2)))
        wear = self._wear_penalty(action_vector)
        reward = -(
            w.energy * energy
            + w.comfort * comfort
            + w.violation * violation
            + w.humidity * humidity
            + w.residual * residual
            + w.wear * wear
        )
        components = {
            "energy": energy,
            "comfort": comfort,
            "violation": violation,
            "humidity": humidity,
            "residual": residual,
            "wear": wear,
        }
        self._prev_action = action_vector.copy()
        return reward, components

    # --- component helpers -------------------------------------------------
    def _comfort_penalty(self, obs: np.ndarray) -> float:
        penalty = 0.0
        for name, target in self.config.comfort_targets.items():
            idx = self._obs_index.get(name)
            if idx is None:
                continue
            deviation = abs(obs[idx] - target) - self.config.comfort_band
            penalty += max(0.0, deviation)
        return penalty

    def _humidity_penalty(self, obs: np.ndarray, info: Dict) -> float:
        humidity_value = info.get("humidity", obs[-1])
        lo, hi = self.config.humidity_bounds
        return max(0.0, lo - humidity_value) + max(0.0, humidity_value - hi)

    def _wear_penalty(self, action: np.ndarray) -> float:
        if self._prev_action is None:
            return 0.0
        return float(np.abs(action - self._prev_action).mean())
