"""Factory for disturbance modules."""

from __future__ import annotations

from importlib import import_module
from typing import Dict, Iterable, List

import numpy as np

from .disturbances.base import Disturbance


def build_disturbances(specs: Iterable[Dict]) -> List[Disturbance]:
    modules: List[Disturbance] = []
    for spec in specs:
        class_path = spec["class_path"]
        kwargs = spec.get("params", {})
        module_name, class_name = class_path.rsplit(".", 1)
        module = import_module(module_name)
        cls = getattr(module, class_name)
        modules.append(cls(**kwargs))
    return modules


def apply_disturbances(obs: np.ndarray, action: np.ndarray, disturbances: List[Disturbance]):
    corrupted_obs = obs
    corrupted_action = action
    for dist in disturbances:
        corrupted_obs = dist.apply_obs(corrupted_obs)
        corrupted_action = dist.apply_action(corrupted_action)
    return corrupted_obs, corrupted_action
