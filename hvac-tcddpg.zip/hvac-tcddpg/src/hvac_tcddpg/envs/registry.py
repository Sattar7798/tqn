"""Environment factory."""

from __future__ import annotations

from pathlib import Path
from typing import Any, Dict

import yaml

from .base_env import EnvConfig
from .rc_env import RCEnv
from .synth_env import SyntheticHVACEnv

try:
    from .eplus_env import EnergyPlusHVACEnv
except (ModuleNotFoundError, ImportError):  # pragma: no cover - optional EnergyPlus installation
    EnergyPlusHVACEnv = None  # type: ignore

ENV_TYPES = {
    "rc": RCEnv,
    "energyplus": EnergyPlusHVACEnv,
    "synthetic": SyntheticHVACEnv,
}


def load_env_config(config_path: str | Path) -> EnvConfig:
    config_path = Path(config_path)
    cfg_dict = yaml.safe_load(config_path.read_text())
    normalization = cfg_dict.get("normalization")
    if normalization:
        normalization = str((config_path.parent / normalization).resolve())
    return EnvConfig(
        name=cfg_dict["name"],
        delta_t_minutes=cfg_dict["delta_t_minutes"],
        observation_items=tuple(cfg_dict["observation_items"]),
        action_items=tuple(cfg_dict["action_items"]),
        normalization_path=normalization,
        disturbances=tuple(cfg_dict.get("disturbances", [])),
        reward=cfg_dict.get("reward"),
        config_dir=str(config_path.parent.resolve()),
    )


def make_env(config_path: str | Path):
    cfg = yaml.safe_load(Path(config_path).read_text())
    env_type = cfg["backend"]
    config = load_env_config(config_path)
    env_cls = ENV_TYPES.get(env_type)
    if env_cls is None:
        raise ValueError(f"Unsupported backend: {env_type}")
    return env_cls(config=config, backend_settings=cfg.get("backend_settings", {}))
