"""Reduced-order RC surrogate environment."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Tuple

import gymnasium as gym
import numpy as np
import pandas as pd

from .base_env import EnvConfig, HVACEnv
from .reward import RewardModel
from ..physics.energy_balance import rc_step
from ..physics.thermo_projection import ThermoProjection


@dataclass
class RCBackendSettings:
    params_path: str
    rollout_csv: str
    projection: Dict


class RCEnv(HVACEnv):
    """Multi-zone RC surrogate calibrated against EnergyPlus data."""

    def __init__(self, config: EnvConfig, backend_settings: Dict):
        super().__init__(config)
        self.settings = RCBackendSettings(**backend_settings)
        base = Path(config.config_dir or ".")
        self.params = self._load_params(base / self.settings.params_path)
        self.rollout = pd.read_parquet(base / self.settings.rollout_csv)
        self.state_cols = [c for c in self.rollout.columns if c.startswith("state_")]
        self.action_cols = [c for c in self.rollout.columns if c.startswith("action_")]
        self.observation_space = gym.spaces.Box(
            low=-np.inf, high=np.inf, shape=(len(config.observation_items),), dtype=np.float32
        )
        self.action_space = gym.spaces.Box(
            low=-1.0, high=1.0, shape=(len(config.action_items),), dtype=np.float32
        )
        self._projection = ThermoProjection(**self.settings.projection)
        self._reward_model = RewardModel(config.reward, config.observation_items) if config.reward else None
        self._prev_action = np.zeros(len(config.action_items), dtype=np.float64)

    @staticmethod
    def _load_params(path: Path | str) -> Dict[str, np.ndarray]:
        params = np.load(Path(path), allow_pickle=True)
        return {k: params[k] for k in params.files}

    def reset(self, *, seed=None, options=None):
        super().reset(seed=seed, options=options)
        self._time_index = 0
        self._state = self.rollout.loc[self._time_index, self.state_cols].to_numpy(dtype=np.float64)
        obs = self._extract_observation()
        norm_obs = self._normalize_obs(obs)
        info = {"time_index": self._time_index, "raw_obs": obs}
        return norm_obs, info

    def step(self, action: np.ndarray):
        physical_action = self._denormalize_action(action)
        projected, proj_info = self._projection(np.asarray(physical_action), self._state)
        next_state = rc_step(self._state, projected, self.params, self.delta_t_hours)
        disturbances = self.rollout.loc[self._time_index, "disturbances"] if "disturbances" in self.rollout.columns else None
        info = {
            "projection": proj_info,
            "disturbances": disturbances,
            "energy_proxy": float(np.linalg.norm(projected)),
            "humidity": float(self._state[-1]) if len(self._state) else 0.0,
        }
        self._state = next_state
        self._time_index += 1
        terminated = self._time_index >= len(self.rollout) - 1
        obs = self._extract_observation()
        norm_obs = self._normalize_obs(obs)
        info["raw_obs"] = obs
        reward = self._compute_reward(obs, projected, info)
        return norm_obs, reward, terminated, False, info

    def _compute_reward(self, obs: np.ndarray, action: np.ndarray, info: Dict) -> float:
        if self._reward_model:
            reward, components = self._reward_model(obs, action, info)
            info["reward_components"] = components
            return reward
        comfort = np.sum(np.abs(obs - 0.0))
        energy = np.linalg.norm(action, ord=2)
        penalty = info["projection"]["penalty"]
        info["reward_components"] = {"energy": energy, "comfort": comfort, "violation": penalty}
        return -(energy + comfort + penalty)

    def _extract_observation(self) -> np.ndarray:
        obs = []
        for name in self.config.observation_items:
            obs.append(self._lookup(name))
        return np.asarray(obs, dtype=np.float32)

    def _lookup(self, name: str) -> float:
        if name in self.rollout.columns:
            return float(self.rollout.loc[self._time_index, name])
        raise KeyError(f"Unknown observation item {name}")
