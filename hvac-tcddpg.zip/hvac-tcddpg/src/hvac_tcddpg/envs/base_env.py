"""Common utilities for HVAC environments."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Dict, Tuple

import gymnasium as gym
import numpy as np

from ..utils.normalization import Normalizer


@dataclass
class EnvConfig:
    """Generic environment configuration."""

    name: str
    delta_t_minutes: int
    observation_items: Tuple[str, ...]
    action_items: Tuple[str, ...]
    normalization_path: str | None = None
    disturbances: Tuple[Dict[str, Any], ...] = ()
    reward: Dict[str, Any] | None = None
    config_dir: str | None = None


class HVACEnv(gym.Env, ABC):
    """Base class that standardizes bookkeeping across EnergyPlus and RC envs."""

    metadata = {"render_modes": []}

    def __init__(self, config: EnvConfig):
        super().__init__()
        self.config = config
        self._last_action = None
        self._time_index = 0
        self.normalizer = Normalizer(config.normalization_path)

    @abstractmethod
    def reset(self, *, seed: int | None = None, options: Dict[str, Any] | None = None):
        """Reset the environment."""

    @abstractmethod
    def step(self, action: np.ndarray):
        """Advance the environment."""

    def render(self):
        return None

    @property
    def delta_t_hours(self) -> float:
        return self.config.delta_t_minutes / 60.0

    def _normalize_obs(self, obs: np.ndarray) -> np.ndarray:
        return self.normalizer.normalize_obs(obs)

    def _denormalize_action(self, action: np.ndarray) -> np.ndarray:
        return self.normalizer.denormalize_action(action)
