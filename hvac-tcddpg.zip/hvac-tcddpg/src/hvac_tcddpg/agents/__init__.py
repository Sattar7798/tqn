"""Agent factory."""

from .tc_ddpg.learner import TCDDPGLearner
from .tc_ddpg.config import AgentConfig


def build_agent(config: AgentConfig, observation_space, action_space):
    return TCDDPGLearner(config=config, observation_space=observation_space, action_space=action_space)


__all__ = ["build_agent", "TCDDPGLearner", "AgentConfig"]
