"""Implementation of TC-DDPG learner."""

from __future__ import annotations

from dataclasses import asdict

import torch
import torch.nn.functional as F
from torch.optim import Adam

from .actor import Actor
from .critic import Critic
from .config import AgentConfig
from .noise import OUNoise
from .replay_buffer import ReplayBuffer
from ...physics.thermo_projection import ThermoProjection


class TCDDPGLearner:
    def __init__(self, config: AgentConfig, observation_space, action_space):
        self.config = config
        obs_dim = observation_space.shape[0]
        act_dim = action_space.shape[0]
        self.device = torch.device(config.device if torch.cuda.is_available() else "cpu")
        self.actor = Actor(obs_dim, act_dim, config.network.hidden_dims).to(self.device)
        self.actor_target = Actor(obs_dim, act_dim, config.network.hidden_dims).to(self.device)
        self.critic = Critic(obs_dim, act_dim, config.network.hidden_dims).to(self.device)
        self.critic_target = Critic(obs_dim, act_dim, config.network.hidden_dims).to(self.device)
        self.actor_target.load_state_dict(self.actor.state_dict())
        self.critic_target.load_state_dict(self.critic.state_dict())
        self.actor_opt = Adam(self.actor.parameters(), lr=config.actor_lr)
        self.critic_opt = Adam(self.critic.parameters(), lr=config.critic_lr)
        self.buffer = ReplayBuffer(obs_dim, act_dim, config.buffer_size)
        self.noise = OUNoise(act_dim)
        self.projection = ThermoProjection(
            sat_bounds=(10, 17), sat_rate_limit=0.5, flow_min=0.1, flow_max=1.0, humidity_bounds=(0.3, 0.6)
        )

    def act(self, obs, noise: bool = True):
        obs_t = torch.as_tensor(obs, dtype=torch.float32, device=self.device).unsqueeze(0)
        with torch.no_grad():
            action = self.actor(obs_t).cpu().numpy().squeeze(0)
        if noise:
            action += self.noise.sample()
        action, _ = self.projection(action, obs)
        return action

    def update(self):
        if self.buffer.size < self.config.batch_size:
            return {}
        batch = self.buffer.sample(self.config.batch_size)
        obs = torch.as_tensor(batch.obs, dtype=torch.float32, device=self.device)
        acts = torch.as_tensor(batch.actions, dtype=torch.float32, device=self.device)
        rews = torch.as_tensor(batch.rewards, dtype=torch.float32, device=self.device)
        next_obs = torch.as_tensor(batch.next_obs, dtype=torch.float32, device=self.device)
        dones = torch.as_tensor(batch.dones, dtype=torch.float32, device=self.device)

        with torch.no_grad():
            noise = torch.clamp(torch.randn_like(acts) * 0.2, -0.5, 0.5)
            next_actions = torch.clamp(self.actor_target(next_obs) + noise, -1.0, 1.0)
            q1_target, q2_target = self.critic_target(next_obs, next_actions)
            q_target = torch.min(q1_target, q2_target)
            y = rews + self.config.gamma * (1 - dones) * q_target

        q1, q2 = self.critic(obs, acts)
        critic_loss = F.mse_loss(q1, y) + F.mse_loss(q2, y)
        self.critic_opt.zero_grad()
        critic_loss.backward()
        self.critic_opt.step()

        if self.buffer.ptr % self.config.update_freq == 0:
            policy_actions = self.actor(obs)
            actor_loss = -self.critic(obs, policy_actions)[0].mean()
            self.actor_opt.zero_grad()
            actor_loss.backward()
            self.actor_opt.step()
            self._soft_update()
        else:
            actor_loss = torch.tensor(0.0)
        return {"critic_loss": critic_loss.item(), "actor_loss": actor_loss.item()}

    def _soft_update(self):
        tau = self.config.tau
        for target, source in zip(self.actor_target.parameters(), self.actor.parameters()):
            target.data.copy_(tau * source.data + (1 - tau) * target.data)
        for target, source in zip(self.critic_target.parameters(), self.critic.parameters()):
            target.data.copy_(tau * source.data + (1 - tau) * target.data)
