"""Exploration noise processes."""

from __future__ import annotations

import numpy as np


class OUNoise:
    def __init__(self, dim: int, mu=0.0, theta=0.15, sigma=0.2):
        self.mu = mu
        self.theta = theta
        self.sigma = sigma
        self.state = np.ones(dim) * mu

    def reset(self):
        self.state.fill(self.mu)

    def sample(self):
        dx = self.theta * (self.mu - self.state) + self.sigma * np.random.randn(*self.state.shape)
        self.state += dx
        return self.state
