"""Configuration dataclasses for TC-DDPG."""

from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class NetworkConfig:
    hidden_dims: tuple[int, ...] = (256, 256)
    activation: str = "relu"


@dataclass
class AgentConfig:
    actor_lr: float = 3e-4
    critic_lr: float = 3e-4
    gamma: float = 0.995
    tau: float = 5e-3
    batch_size: int = 512
    buffer_size: int = 2_000_000
    update_freq: int = 2
    warmup_steps: int = 10_000
    device: str = "cuda"
    network: NetworkConfig = field(default_factory=NetworkConfig)
