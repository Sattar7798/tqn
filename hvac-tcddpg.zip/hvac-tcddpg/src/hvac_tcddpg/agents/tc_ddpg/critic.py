"""Twin critic network."""

from __future__ import annotations

import torch
import torch.nn as nn


def _build_mlp(input_dim: int, hidden_dims):
    layers = []
    in_dim = input_dim
    for dim in hidden_dims:
        layers.append(nn.Linear(in_dim, dim))
        layers.append(nn.ReLU())
        in_dim = dim
    layers.append(nn.Linear(in_dim, 1))
    return nn.Sequential(*layers)


class Critic(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int, hidden_dims=(256, 256)):
        super().__init__()
        self.q1 = _build_mlp(obs_dim + act_dim, hidden_dims)
        self.q2 = _build_mlp(obs_dim + act_dim, hidden_dims)

    def forward(self, obs: torch.Tensor, act: torch.Tensor):
        xu = torch.cat([obs, act], dim=-1)
        return self.q1(xu), self.q2(xu)
