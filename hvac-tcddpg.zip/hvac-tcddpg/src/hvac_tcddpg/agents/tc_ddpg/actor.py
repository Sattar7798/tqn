"""Actor network."""

from __future__ import annotations

import torch
import torch.nn as nn


class Actor(nn.Module):
    def __init__(self, obs_dim: int, act_dim: int, hidden_dims=(256, 256), activation: str = "relu"):
        super().__init__()
        layers = []
        in_dim = obs_dim
        act_cls = nn.ReLU if activation == "relu" else nn.GELU
        for dim in hidden_dims:
            layers.append(nn.Linear(in_dim, dim))
            layers.append(act_cls())
            in_dim = dim
        layers.append(nn.Linear(in_dim, act_dim))
        layers.append(nn.Tanh())
        self.net = nn.Sequential(*layers)

    def forward(self, obs: torch.Tensor) -> torch.Tensor:
        return self.net(obs)
